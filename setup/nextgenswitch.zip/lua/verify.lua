local err,data = verify_license()
return data