SERVER_API_URL = "http://sg.nextgenswitch.com/api/switch"
API_USERNAME = "admin"
API_PASSOWRD = "admin"
USE_AGI = false
FASTAGI_HOST = "127.0.0.1:6785"
