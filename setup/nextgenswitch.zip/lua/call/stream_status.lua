local json = require "lua/json"
local redisclient  = require "lua/redisclient"
local capture  = require "lua/capture" 
local urlcode = require'lua/urlcode'
dofile("lua/config.lua")
local jsondata = json.decode(jsonstr)
local curactiondata = redisclient.get("stream:" .. urlcode.encode(jsondata.stream_name))
--print("current data")
--print(curactiondata)
if(jsondata.event == "stopped") then err = redisclient.del("stream:" .. jsondata.stream_name) end
local curaction = {}
if(curactiondata) then curaction = json.decode(curactiondata) end

if(curaction.statusCallback == nil) then return end
--print("come here 2")
local data = {}
data.url = curaction.statusCallback
data.call_id = jsondata.call_id
data.method = curaction.statusCallbackMethod
data.body = jsondata



local err,resp = capture.agi("/call/url_request",json.encode(data))