local json = require "lua/json"
local redisclient = require "lua/redisclient"
local capture = require "lua/capture"
local lfs_ok, lfs = pcall(require, "lfs")

dofile("lua/config.lua")

local jsondata = json.decode(jsonstr)

redisclient.set("cdr:" .. jsondata["call_id"], jsonstr)
redisclient.expire("cdr:" .. jsondata["call_id"], 3600)
--print("sending json for call update " .. jsonstr)
--local err, resp = curl_post(SERVER_API_URL .. "/call/update", jsonstr)
local err, resp = capture.agi("/call/update", jsonstr)
--print("call update err " .. err, resp)

if (jsondata.disconnect_time > 0) then
    --print("deleting redis data for call")
    redisclient.expire("cdr:" .. jsondata["call_id"], 600)
    redisclient.del("actions:" .. jsondata["call_id"])
    redisclient.del("action:" .. jsondata["call_id"])
    redisclient.del("modify:" .. jsondata["call_id"])

    local logs_dir = "logs"
    local ts = tonumber(jsondata.disconnect_time) or os.time()
    local month = os.date('%Y-%m', ts)
    local csv_path = logs_dir .. '/call_history_' .. month .. '.csv'

    local function ensure_logs_dir()
        if lfs_ok and lfs then
            local attr = lfs.attributes(logs_dir)
            if attr and attr.mode == "directory" then
                return true
            end
            return lfs.mkdir(logs_dir)
        end

        local sep = package.config:sub(1, 1)
        if sep == "\\" then
            os.execute('if not exist "' .. logs_dir .. '" mkdir "' .. logs_dir .. '"')
            return true
        end

        local res = os.execute('mkdir -p "' .. logs_dir .. '"')
        return res == true or res == 0
    end

    local function escape_csv(value)
        if value == nil then
            value = ""
        elseif type(value) == "boolean" then
            value = value and "true" or "false"
        elseif type(value) ~= "string" then
            value = tostring(value)
        end
        if value:find('[\",\n]') then
            value = '"' .. value:gsub('"', '""') .. '"'
        end
        return value
    end

    local base_columns = {
        "call_id",
        "status",
        "channel",
        "disconnect_code",
        "connect_time",
        "ringing_time",
        "establish_time",
        "disconnect_time",
        "direction",
    }

    local function build_columns()
        local columns = {}
        local seen = {}

        for _, key in ipairs(base_columns) do
            table.insert(columns, key)
            seen[key] = true
        end

        for key, _ in pairs(jsondata) do
            if not seen[key] then
                table.insert(columns, key)
                seen[key] = true
            end
        end

        table.sort(columns, function(a, b)
            local ia, ib
            for idx, name in ipairs(base_columns) do
                if name == a then ia = idx end
                if name == b then ib = idx end
            end

            if ia and ib then
                return ia < ib
            elseif ia then
                return true
            elseif ib then
                return false
            end

            return a < b
        end)

        return columns
    end

    local function read_existing_header(path)
        local file = io.open(path, "r")
        if not file then
            return nil
        end
        local line = file:read("*l")
        file:close()

        if not line or line == "" then
            return nil
        end

        line = line:gsub('\r$', '')

        local columns = {}
        for column in line:gmatch("([^,]+)") do
            column = column:gsub('^%s+', ''):gsub('%s+$', '')
            table.insert(columns, column)
        end

        return columns
    end

    local existing_columns = read_existing_header(csv_path)
    local columns = existing_columns or build_columns()

    if existing_columns then
        local known = {}
        for _, name in ipairs(existing_columns) do
            known[name] = true
        end
        for key, _ in pairs(jsondata) do
            if not known[key] then
                print("CSV header missing column for field: " .. key)
            end
        end
    end

    local fields = {}
    for _, key in ipairs(columns) do
        local value = jsondata[key]
        if type(value) == "table" then
            if type(json.encode) == "function" then
                value = json.encode(value)
            else
                value = tostring(value)
            end
        end
        table.insert(fields, escape_csv(value))
    end

    if ensure_logs_dir() then
        local header_needed = false
        local check = io.open(csv_path, "r")
        if check then
            check:close()
        else
            header_needed = true
        end

        local file, ferr = io.open(csv_path, "a")
        if file then
            if header_needed then
                file:write(table.concat(columns, ",") .. "\n")
            end
            file:write(table.concat(fields, ",") .. "\n")
            file:close()
        else
            print("Unable to open CSV file: " .. csv_path .. " error: " .. tostring(ferr))
        end
    else
        print("Unable to ensure logs directory exists: " .. logs_dir)
    end
end

