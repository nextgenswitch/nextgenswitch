local redis = {}
local base64 = require'lua/base64'


function return_val(val)
    if(val == nil) then return val end
    return base64.decode(val)
end     

function redis.get(key)
   return return_val(redis_cmd_get("GET",key))
end    

function redis.set(key,val)
    return redis_cmd_set("SET",key,base64.encode(val))
end    

function redis.lpop(key)
    return return_val(redis_cmd_get("LPOP",key))
end    
 
function redis.lpush(key,val)
     return redis_cmd_set("LPUSH",key,base64.encode(val))
end 

function redis.rpop(key)
    return return_val(redis_cmd_get("RPOP",key))
end  

function redis.rpush(key,val)
    return redis_cmd_set("RPUSH",key,base64.encode(val))
end 

function redis.del(key)
    return redis_cmd_get("DEL",key)
end

function redis.expire(key,val)
    return redis_cmd_set("EXPIRE",key,tostring(val))
end

function redis.customfunc(key,val)
    return redis_cmd_get(key,val)
end



return redis
